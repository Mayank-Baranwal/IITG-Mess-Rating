Refer to Group18-IITG_Mess_Rating_System.pdf for documentation + login credentials
